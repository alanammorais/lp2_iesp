
package modelo;

public class Circulo {
    
    //Atributo
    private float raio;
    
    //Construtor
    public Circulo(float r){
        this.raio = r;
    }
    
    //Metodos
    public float area(){
        //pi*raio2
        return (float)(this.raio*this.raio*3.14);
    }
    
    public float perimetro(){
        //2*pi*raio
        return (float)(2*3.14*this.raio);
    }
    
}
