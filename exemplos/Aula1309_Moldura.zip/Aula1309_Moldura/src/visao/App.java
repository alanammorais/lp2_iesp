package visao;

import javax.swing.JOptionPane;

import modelo.MolduraRetangular;
import modelo.Retangulo;

public class App {
	
	public static void main(String[] args) {
		
		float base, altura, espessura; 
		String baseS, alturaS, espessuraS;
		
		baseS = JOptionPane.showInputDialog("Digite a base da Moldura: ");
		alturaS = JOptionPane.showInputDialog("Digite a altura da Moldura: ");
		espessuraS = JOptionPane.showInputDialog("Digite a espessura da Moldura: ");
		
		base = Float.parseFloat(baseS);
		altura = Float.parseFloat(alturaS);
		espessura = Float.parseFloat(espessuraS);
		
		Retangulo rMa = new Retangulo(base, altura);
		Retangulo rMe = new Retangulo(base-(2*espessura), altura-(2*espessura));
		
		MolduraRetangular mR = new MolduraRetangular(rMa, rMe);
		
		JOptionPane.showMessageDialog(null, "�rea da Moldura: "+ mR.areaMoldura());
		
		
		/*float base, altura, area; 
		String baseS, alturaS;
		
		baseS = JOptionPane.showInputDialog("Digite a base: ");
		alturaS = JOptionPane.showInputDialog("Digite a altura: ");
		
		base = Float.parseFloat(baseS);
		altura = Float.parseFloat(alturaS);
		
		Retangulo ret1 = new Retangulo(base, altura);
		
		JOptionPane.showMessageDialog(null, "A �rea do Ret�ngulo �: "+ ret1.calcularArea());
		
		Circulo c1 = new Circulo(10);
		System.out.println(c1.area());
		
		c1.setRaio(7);
		System.out.println(c1.getRaio());
		System.out.println(c1.area());
		*/
		
	}
	
	
	/*public static float calcularArea(float b, float h){
		return (b * h);
	}

	public static void main(String[] args) {
		float base, altura, area; 
		String baseS, alturaS;
		
		baseS = JOptionPane.showInputDialog("Digite a base: ");
		alturaS = JOptionPane.showInputDialog("Digite a altura: ");
		
		base = Float.parseFloat(baseS);
		altura = Float.parseFloat(alturaS);
		
		area = calcularArea(base, altura);
		
		JOptionPane.showMessageDialog(null, "A �rea do Ret�ngulo �: "+ area);
	
	}*/

}
