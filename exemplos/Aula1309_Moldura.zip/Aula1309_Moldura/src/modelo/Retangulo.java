package modelo;

public class Retangulo {
	
	//Atributos - private
	private float base;
	private float altura;
	
	//Construtor
	public Retangulo(float b, float h) {
		this.base = b;
		this.altura = h;
	} 
	
	//getters e setters
	public float getBase() {
		return this.base;
	}
	
	public void setBase(float b) {
		this.base = b;
	}
	
	public float getAltura() {
		return this.altura;
	}
	
	public void setAltura(float a) {
		this.altura = a;
	}
	
	//Metodos
	public float calcularArea(){
		return (base * altura);
	}
	
	
	
}
