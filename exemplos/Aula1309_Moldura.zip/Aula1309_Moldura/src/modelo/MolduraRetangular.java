package modelo;

public class MolduraRetangular {
	
	//Atributos
	private Retangulo rMaior;
	private Retangulo rMenor;
	
	//Construtor
	public MolduraRetangular(Retangulo rMa, Retangulo rMe) {
		this.rMaior = rMa;
		this.rMenor = rMe;
	}
	
	//Get e Set
	public Retangulo getRMaior() {
		return this.rMaior;
	}
	
	public void setRMaior(Retangulo r1) {
		this.rMaior = r1;
	}
	
	public Retangulo getRMenor() {
		return this.rMenor;
	}
	
	public void setRMenor(Retangulo r2) {
		this.rMenor = r2;
	}
	
	//Metodos
	public float areaMoldura() {
		return rMaior.calcularArea()-rMenor.calcularArea();
	}
	

}
