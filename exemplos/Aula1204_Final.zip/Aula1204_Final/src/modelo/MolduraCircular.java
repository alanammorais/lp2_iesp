
package modelo;


public class MolduraCircular {
    
    //atributos
    private Circulo cMenor;
    private Circulo cMaior;
    
    //construtor
    public MolduraCircular(Circulo circuloMenor, Circulo circuloMaior){
        this.cMaior = circuloMaior;
        this.cMenor = circuloMenor;    
    }

    public Circulo getcMenor() {
        return cMenor;
    }

    public void setcMenor(Circulo cMenor) {
        this.cMenor = cMenor;
    }

    public Circulo getcMaior() {
        return cMaior;
    }

    public void setcMaior(Circulo cMaior) {
        this.cMaior = cMaior;
    }
    
    public float areaMCircular(){
        return (cMaior.area()-cMenor.area());
    }
}
