
package modelo;

public class Retangulo {
    
    //Atributos
    private float base;
    private float altura;
    
    //Construtor
    public Retangulo(float b, float a){
        this.base = b;
        this.altura = a;        
    }
    
    //metodos
    public float area(){
        return this.base*this.altura;
    }
    
    public float perimetro(){
        return 2*(this.base+this.altura);
    }
  
    
}
