package modelo;

public class Moldura {
 
    //Atributos
    private Retangulo rMaior;
    private Retangulo rMenor;
    
    //construtor
    public Moldura(Retangulo retanguloMenor, Retangulo retanguloMaior){
        this.rMaior = retanguloMaior;
        this.rMenor = retanguloMenor;
    }
    
    //metodos
    public float areaMoldura(){
        float a = rMaior.area()-rMenor.area();
        return a;
    }
}
