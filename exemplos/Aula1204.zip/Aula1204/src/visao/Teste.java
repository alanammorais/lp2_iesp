
package visao;

import javax.swing.JOptionPane;
import modelo.Circulo;
import modelo.Moldura;
import modelo.Retangulo;

public class Teste {
            
    public static void main (String[] args){
       
        Retangulo r1 = new Retangulo(10, 15);
        Retangulo r2 = new Retangulo(8, 13);
        
        //Muda a base r1 = 12
        
        Moldura m = new Moldura(r2, r1);
        
        System.out.println("R Maior:"+ r1.area());
        System.out.println("R Menor:"+ r2.area());
        System.out.println("Area Moldura: "+m.areaMoldura());
        
        
        
       /*Circulo c = new Circulo(5);
       JOptionPane.showMessageDialog(null, "Area:"+c.area()+" Perímetro:"+c.perimetro()); 
       */
       /*Retangulo r1; 
       float b, a;
       String bS, aS;
       
       bS = JOptionPane.showInputDialog("Base do Retângulo:");
       b = Float.valueOf(bS);
       
       aS = JOptionPane.showInputDialog("Altura do Retângulo:");
       a = Float.valueOf(aS);
       
       r1 = new Retangulo(b, a);
       
       //System.out.println("Area:"+r1.area()+" Perímetro:"+r1.perimetro());
       JOptionPane.showMessageDialog(null, "Area:"+r1.area()+" Perímetro:"+r1.perimetro());
        */
       /*Retangulo r1 = new Retangulo(5, 10);
       System.out.println(r1.area());
       
       Retangulo r2 = new Retangulo(10, 2);
       System.out.println(r2.area());*/
             
    
    }
    
}
