package model;


public class Funcionario {
    //Atributos
    private String nome;
    private int matricula;
    private float salario;

    //Construtor
    public Funcionario(String nome, int matricula, float salario) {
        this.nome = nome;
        this.matricula = matricula;
        this.salario = salario;
    }


    //get e set
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getMatricula() {
        return matricula;
    }

    public void setMatricula(int matricula) {
        this.matricula = matricula;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }
    
    //toString
    public String toString() {
        return "Funcionario{" + "nome=" + nome + ", matricula=" + matricula + ", salario=" + salario + '}';
    }
    
   
    
}
