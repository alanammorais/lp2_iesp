package teste;

import model.Funcionario;
import model.Pessoa;

public class App {
    
    public static void main(String args[]){
        int [][] identidade = new int[3][3];
        
        for (int i=0; i<3; i++){
            for (int j=0; j<3; j++){
                if (i==j)
                    identidade[i][j]=1;
                else
                    identidade[i][j]=0;
            }
        }
        
        for (int i=0; i<3; i++){
            System.out.println();
            for (int j=0; j<3; j++){
                System.out.print(identidade[i][j]+" ");
            }
        }
        
        /*
        Funcionario lista[] = new Funcionario[3];
        
        Funcionario f1 = new Funcionario("Alana", 1435, 100000);
        lista[0] = f1;
        lista[1] = new Funcionario("Cicero", 687, 500000);
        
        for (int i =0; i< lista.length; i++){
            System.out.println(lista[i]);
        }
        */
        
        /*char [] listaValores = new char[5];
        
        listaValores[0]='a';
        listaValores[1]='b';
        listaValores[2]='c';
        listaValores[3]='d';
        listaValores[4]='e';
    
        for (int i = listaValores.length-1 ; i>=0; i--){
            //System.out.print(listaValores[i]+" ");
        }
        */
        
        /*
        //Lista Pessoas
        Pessoa[] listaP = new Pessoa[5];
        
        Pessoa p1 = new Pessoa("Ivo", 1001);
        listaP[0] = p1;
        
        Pessoa p2 = new Pessoa("Carlos", 1002);
        listaP[1] = p2;
        
        Pessoa p3 = new Pessoa("João", 1003);
        listaP[2] = p3;
        
        Pessoa p4 = new Pessoa("Ewerton", 1012);
        listaP[3] = p4;
        
        listaP[4]= p4;
        
        for (int i=0; i< listaP.length; i++){
            System.out.println(listaP[i]);
        }
        */
        
    
    }
    
}
