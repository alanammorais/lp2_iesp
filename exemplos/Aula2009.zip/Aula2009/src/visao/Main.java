package visao;

import javax.swing.JOptionPane;

import modelo.Pessoa;

public class Main {

	public static void main(String[] args) {
		 int[] arr = new int [3];
		 arr [0] = 1;
		 
		 Pessoa[] listaAlunos = new Pessoa[2];
		 
		 for (int i = 0; i< listaAlunos.length; i++) {
			 String nome = JOptionPane.showInputDialog("Digite seu nome:");
			 String cpf = JOptionPane.showInputDialog("Digite seu CPF:");
			
			 listaAlunos[i] = new Pessoa(nome, cpf);
		 }

		 JOptionPane.showMessageDialog(null, listaAlunos.toString());
		 System.out.println(listaAlunos.toString());
		 
	}

}
