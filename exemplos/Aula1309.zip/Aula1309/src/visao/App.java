package visao;

import javax.swing.JOptionPane;

import modelo.Circulo;
import modelo.Retangulo;

public class App {
	
	public static void main(String[] args) {
		float base, altura, area; 
		String baseS, alturaS;
		
		baseS = JOptionPane.showInputDialog("Digite a base: ");
		alturaS = JOptionPane.showInputDialog("Digite a altura: ");
		
		base = Float.parseFloat(baseS);
		altura = Float.parseFloat(alturaS);
		
		Retangulo ret1 = new Retangulo(base, altura);
		
		JOptionPane.showMessageDialog(null, "A �rea do Ret�ngulo �: "+ ret1.calcularArea());
		
		Circulo c1 = new Circulo(10);
		System.out.println(c1.area());
		
		c1.setRaio(7);
		System.out.println(c1.getRaio());
		System.out.println(c1.area());
		
		
	}
	
	
	/*public static float calcularArea(float b, float h){
		return (b * h);
	}

	public static void main(String[] args) {
		float base, altura, area; 
		String baseS, alturaS;
		
		baseS = JOptionPane.showInputDialog("Digite a base: ");
		alturaS = JOptionPane.showInputDialog("Digite a altura: ");
		
		base = Float.parseFloat(baseS);
		altura = Float.parseFloat(alturaS);
		
		area = calcularArea(base, altura);
		
		JOptionPane.showMessageDialog(null, "A �rea do Ret�ngulo �: "+ area);
	
	}*/

}
