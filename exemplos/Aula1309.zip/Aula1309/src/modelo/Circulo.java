package modelo;

public class Circulo {
	
	//Atributos - private
	private float raio;
	
	//Construtor
	public Circulo(float r) {
		this.raio = r;
	}

	//Alterar - SET
	public void setRaio(float r) {
		this.raio = r;
	}
	
	//Obter Valores -GET
	public float getRaio() {
		return this.raio;
	}
	
	
	
	//Metodos
	public float area() {
		return (float)(raio*raio*3.14);
	}

}
