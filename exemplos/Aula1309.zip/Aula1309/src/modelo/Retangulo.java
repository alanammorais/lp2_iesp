package modelo;

public class Retangulo {
	
	//Atributos - private
	private float base;
	private float altura;
	
	//Construtor
	public Retangulo(float b, float h) {
		this.base = b;
		this.altura = h;
	} 
	
	//Metodos
	public float calcularArea(){
		return (base * altura);
	}
	
	
	
}
