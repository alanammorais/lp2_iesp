package principal;

public class Repeticao {

	public static void main(String[] args) {

		int valorTabuada = 5;
		
		for(int i=1; i<=valorTabuada ; i++) {
			int conta = valorTabuada*i;
			System.out.println(valorTabuada+" x "+i+"= "+ conta);
		}
		
		
	}

}
