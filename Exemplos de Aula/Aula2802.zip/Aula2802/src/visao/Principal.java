package visao;

import java.util.Scanner;

import javax.swing.JOptionPane;

public class Principal {
	
	public static String gerarTabuada(int v) {
		String retorno = "";
		for (int i=0; i<11; i++) {
			retorno = retorno+"\n"+i+"x"+v+" = "+(i*v);
		}
		return retorno;
	}
	
	
	public static void main(String[] args) {
		int valor;
		String valorS;
		String saida;
		Scanner entrada = new Scanner(System.in);
		
		//Interface Gr�fica
		//valorS = JOptionPane.showInputDialog("Digite o valor da tabuada:");
		//valor = Integer.parseInt(valorS);
		
		//Scanner
		System.out.println("Informe o valor: ");
		valor = entrada.nextInt();		
		
		saida = gerarTabuada(valor);
		System.out.println(saida);
		JOptionPane.showMessageDialog(null, saida);
		
		
		
		/*
		float listaNotas[] = new float[5];
		int anos[] = new int[10];
		
		listaNotas[0] = 9.5f;
		listaNotas[1] = 5;
		
		for (int i=0; i<2; i++) {
			System.out.println(listaNotas[i]);
		}
		
		int j = 2;
		while(j<2) {
			System.out.println(listaNotas[j]);
			j++;
		}
		
		j=2;
		do {
			System.out.println("do .. while: "+j);
			j++;
		}while(j<2);
		*/

	}

}
