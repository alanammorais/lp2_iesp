package pacoteExemplo;

public class PrimeiraProjeto {
	
	
	
	public static void main(String[] args) {	
		
		int variavel1;
		
		
		variavel1 = 10;
		System.out.println(variavel1);
		
	} 
	

}