package modelo;

public class Aluno {
	
	//atributos privativos
	private String nome;
	private int matricula;
	private String curso;
	
	
	//construtor - com campos e vazio
	public Aluno() {}
	
	public Aluno(String n, int m, String c) {
		this.nome = n;
		this.matricula = m;
		this.curso = c;
	}

	//get e set
	public String getNome() {
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public int getMatricula() {
		return this.matricula;
	}

	public void setMatricula(int matricula) {
		this.matricula = matricula;
	}

	public String getCurso() {
		return this.curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}
	
	
	
	
	
	
	

}
