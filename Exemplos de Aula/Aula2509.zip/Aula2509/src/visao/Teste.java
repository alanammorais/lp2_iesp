package visao;

import modelo.Aluno;

public class Teste {

	public static void main(String[] args) {
		
		//declarar - tamanho
		int[] numeros = new int[5];
		numeros[0] = 12;
		numeros[1] = 20;
		numeros[4] = 22;
		
		for (int i=0; i < numeros.length ; i++) {
			System.out.println(numeros[i]);
		}
		
		
		String[] listaNomes = new String[5];
		listaNomes[0] = "Leonardo";
		listaNomes[1] = "Alana"; 
		
		
		Aluno[] listaAlunos = {
								new Aluno("João", 321, "Sistemas para Internet"), 
								new Aluno("Paulo", 322, "Sistemas para Internet"), 
								new Aluno("Pedro", 323, "Sistemas para Informação")
							  };
		
		//listaAlunos[3] = new Aluno("Pedro", 355, "Sistemas para Informação"); // Nao funciona
		
		System.out.println("\nLista Alunos:");
		//System.out.println(listaAlunos[0].getNome());
		
		for (int i=0; i < listaAlunos.length ; i++) {
			System.out.println(listaAlunos[i].getNome());
		}
		
		Aluno[] novaLista = new Aluno[4];
		for (int i=0; i < listaAlunos.length ; i++) {
			novaLista[i] = listaAlunos[i];
		}
		
		novaLista[3] = new Aluno("Flávia", 400, "Sistemas para Informação");
		
		System.out.println("\nNova Lista Alunos:");
		
		for (int i=0; i < novaLista.length ; i++) {
			System.out.println(novaLista[i].getNome());
		}
		

	}

}
