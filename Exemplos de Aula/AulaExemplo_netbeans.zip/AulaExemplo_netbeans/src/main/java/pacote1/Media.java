package pacote1;


public class Media {
    public static void main(String[] args){
        
        
        
        
        
        /*float n1=10, n2=5;
        boolean aprovado = false;
        char letra = 103;
        float media;
        
        media = (n1+n2)/2;
        System.out.println(letra);
        
        if(n1 == 10){
            System.out.println("Número 10");
        }else if(n1 == 20){
            System.out.println("Número 20");
        }else{
            System.out.println("Nem 10, nem 20");
        }   
        
        
        //inteiros, char, String
        float a = 7.5f;
        float b = 1;
        float resultado = 0;
        char operacao = '/';
        String op = "add";
        
        switch(op){
            case "add":{
                System.out.println("Soma");
                resultado = a+b;
                break;
            }
            case "dec":{
                System.out.println("Subtrai");
                resultado = a-b;
                break;
            }
            case "mul":{
                System.out.println("Multiplica");
                resultado = a*b;
                break;
            }
            case "div":{
                System.out.println("Divide");
                resultado = a/b;
                break;
            }
            default:
                System.out.println("Operação Inválida");
        }
        
        System.out.println("Resultado: "+resultado);
        
        */
        
        
        
    
    
    }
    
}
