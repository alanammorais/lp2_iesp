package modelo;

public class Lampada {
	
	//atributos
	private boolean estado; //false: desligado true:ligada
	private String cor; 
	
	//construtor
	public Lampada(boolean e, String c) {
		this.estado = e;
		this.cor = c;
	}

	//get e set
	public boolean isEstado() { //getEstado()
		return estado;
	}

	public void setEstado(boolean estado) {
		this.estado = estado;
	}

	public String getCor() {
		return cor;
	}

	public void setCor(String cor) {
		this.cor = cor;
	}
	
	//metodos extras
	
	//toString
	public String toString() {
		String saida = "Estado: "+this.estado+" - Cor: "+this.cor;
		return saida;
	}
	
	

}
