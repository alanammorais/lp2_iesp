package visao;

import modelo.Lampada;

public class Principal {

	public static void main(String[] args) {
		
		Lampada piscaPisca = new Lampada(false, "azul");
		Lampada fluorescente = new Lampada(true, "branca");
		
		//códigos 
		
		System.out.println(piscaPisca);
		System.out.println(fluorescente);
		

	}

}
