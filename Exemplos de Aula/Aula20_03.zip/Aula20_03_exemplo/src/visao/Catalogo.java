package visao;

import javax.swing.JOptionPane;

import modelo.GrupoPesquisa;
import modelo.Pesquisador;

public class Catalogo {

	public static void main(String[] args) {
		Pesquisador p1 = new Pesquisador("Alana", "Brazil", "testes em cobaias");
		Pesquisador p2 = new Pesquisador("Aline", "Brazil", "testes em cobaias");
		Pesquisador p3 = new Pesquisador("Iria", "Japan", "testes em cobaias");
		Pesquisador p4 = new Pesquisador("Roberto", "Brazil", "testes em cobaias");
		Pesquisador p5 = new Pesquisador("Yuri", "Brazil", "testes em cobaias");
		Pesquisador p6 = new Pesquisador("Edson", "Sweden", "testes em cobaias");
		Pesquisador p7 = new Pesquisador("Larissa", "Brazil", "testes em cobaias");
		Pesquisador p8 = new Pesquisador("Suzana", "Cuba", "testes em cobaias");
		Pesquisador p9 = new Pesquisador("Carlos", "USA", "testes em cobaias");
		Pesquisador p10 = new Pesquisador("Diomar", "Australia", "testes em cobaias");
		
		Pesquisador[] lista = new Pesquisador[10];
		lista[0] = p1;
		lista[1] = p2;
		lista[2] = p3;
				
		GrupoPesquisa g1 = new GrupoPesquisa("GP1", "BRASIL", lista);
	
		JOptionPane.showMessageDialog(null, g1);
		
		//Atualizacao
		Pesquisador[] lista2 = new Pesquisador[10];
		lista2[0] = p5;
		lista2[1] = p6;
		lista2[2] = p10;
		lista2[3] = p8;
		
		g1.setListaP(lista2);
		JOptionPane.showMessageDialog(null, g1.getListaP());
		

	}

}
