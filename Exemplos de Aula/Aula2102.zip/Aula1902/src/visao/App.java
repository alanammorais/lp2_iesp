package visao;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class App {

	public static float calcularArea(float b, float h) {
		return b*h;
	}
	
	public static float calcAreaCirculo(float raio) {
		return (float) ((Math.PI)*raio*raio);
	}
	

	public static void main(String[] args) {
		
		float base, altura, raio;
		String raioS;
		
		Scanner entrada = new Scanner(System.in);
		System.out.println("Digite o valor da base: ");
		base = entrada.nextFloat();
		System.out.println("Digite o valor da altura: ");
		altura = entrada.nextFloat();
		
		System.out.println(calcularArea(base, altura));
		
		raioS = JOptionPane.showInputDialog("Digite o valor do raio");
		raio = Float.parseFloat(raioS);
		
		JOptionPane.showMessageDialog(null, calcAreaCirculo(raio));
		
		
		entrada.close();
		
		
		/*
		float valor1 = 10, valor2 = 5, resultado;
		char operacao = 1;
		
		switch (operacao) {
			case 1: 
				resultado = valor1 - valor2;
				System.out.println("O resultado eh: "+resultado);
				break;
			case 2:
				resultado = valor1+ valor2;
				System.out.println("O resultado eh: "+resultado);
				break;
			default:
				System.out.println("Operacao invalida");
		}
		
		*/
		

	}
	
	
}
