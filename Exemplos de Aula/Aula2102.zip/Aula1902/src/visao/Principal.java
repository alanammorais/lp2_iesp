package visao;

public class Principal {

	public static float media(float nota1, float nota2) {
		return (nota1+nota2)/2;
	}
	
	
	public static void main(String[] args) {
		
		float n1 = 10;
		float n2 = 5;
		float media;
		
		media = media(n1, n2);
		System.out.println("A nota do aluno é: "+media);
		
		/*
		int j = 1;
		JOptionPane.showMessageDialog(null, "O valor de j é: "+(++j));
		System.out.println("J: "+ j);
		
		*/
		
	}
	

	
}
