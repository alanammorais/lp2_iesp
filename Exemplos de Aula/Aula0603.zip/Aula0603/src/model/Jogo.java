package model;

public class Jogo {
	//Atributos
	//Composi��o
	public Circulo circ;
	public Retangulo ret;
	
	public Jogo(Circulo c, Retangulo r) {
		this.circ = c;
		this.ret = r;
	}
	
	
	

}
