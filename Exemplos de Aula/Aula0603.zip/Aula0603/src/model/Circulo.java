package model;

public class Circulo {
	
	//Atributos
	public float raio;
	
	//Construtor
	public Circulo(float r) {
		this.raio = r;		
	}
	
	//outros metodos
	public float area() {
		return (3.14f*this.raio*this.raio);
	}
	
	public float perimetro() {
		return (2*3.14f*this.raio);
	}
	

}
