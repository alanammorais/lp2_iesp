package model;

public class Retangulo {
	
	//caracteristas - ATRIBUTOS
	public float base;
	public float altura;
	
	//CONSTRUTOR
	public Retangulo(float b, float h) {
		base = b;
		altura = h;
	}
		
	//metodos
	public float calcularArea() {
		return this.base*this.altura;	
	}
	
	public float calcularPerimetro() {
		return 2*(this.base+this.altura);
	}
	
	
	
	

}
