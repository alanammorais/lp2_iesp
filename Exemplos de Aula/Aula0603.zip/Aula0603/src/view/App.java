package view;

import model.Circulo;
import model.Jogo;
import model.Retangulo;

public class App {

	public static void main(String[] args) {
		
		Circulo c1 = new Circulo(10);
		Retangulo r1 = new Retangulo(10, 5);

		Jogo space = new Jogo(c1, r1);
		
		
		/*
		Circulo c1 = new Circulo(10);
		Circulo c2 = new Circulo(11);
		c1 = c2;
		
		System.out.println("A �rea do c�rculo �: "+c1.area());
		
		c1.raio = 5;
		System.out.println("A �rea do c�rculo �: "+c1.raio);
		
		*/
		/*int i[] = new int[10];
		Retangulo lista[] = new Retangulo[10];
		
		Retangulo r1 = new Retangulo(10, 5);
		System.out.println(r1.calcularArea());
		
		Retangulo r2 = new Retangulo(20, 2);
		System.out.println(r2.calcularArea());
		
		lista[0] = r1;
		System.out.print(r2.altura);*/

	}

}
