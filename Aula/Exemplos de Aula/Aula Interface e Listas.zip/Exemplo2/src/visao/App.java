/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;

import model.Aluno;

public class App {
    
    
    public static void main(String args[]){
    
        //Array tradicionais 
                  // chaves inteiras, 
                  // o mesmo tipo de dado (primitivos, complexos- objetos)
                  // tamanho fixo
        int listaNotas[] = new int[3]; //declaração e inicializando 
        int[] listaNotas2 = {3, 2, 10}; //declarando e inicializando
        
        for(int i = 0; i< listaNotas.length; i++){
            listaNotas[i] = 10;
        }
        
        for(int j = 0; j< listaNotas.length; j++){
            System.out.println("listaNotas:"+listaNotas[j]);
            System.out.println("listaNotas2:"+listaNotas2[j]);
        }
        
        
        //Vetor 3 Alunos
        Aluno[] vetorAluno = new Aluno[3];
        
        Aluno a1 = new Aluno("Alana", "Sistemas");
        vetorAluno[0] = a1;
        
        Aluno a2 = new Aluno("Lucas", "Sistemas de Informação");
        vetorAluno[1] = a2;
        
        //mesma coisa do anterior
        vetorAluno[2] = new Aluno("Altayr", "Sistemas para Internet"); 
        
        for(int j = 0; j< vetorAluno.length; j++){
            System.out.println(vetorAluno[j]);
        }
        
        
        
    }
    
}
