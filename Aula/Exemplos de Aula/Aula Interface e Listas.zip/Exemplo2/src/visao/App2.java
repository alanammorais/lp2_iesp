/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package visao;

import java.util.ArrayList;
import model.Aluno;

/**
 *
 * @author alanamorais
 */
public class App2 {
    
    public static void main(String args[]){
    
        //Arraylist
        // não tem tamaho fixo
        // indices inteiros
        // pode ou não ter tipos diferentes armazenados
        
        //Mesmo tipo de dado
        
        //ArrayList<Aluno> lista = new ArrayList<Aluno>(); //declaração e instaciando
        ArrayList<Float> listaNotas = new ArrayList<Float>(); //declaração e instaciando
        //Interger //Double //Boolean
        listaNotas.add(4.5f);
        listaNotas.add(10f);
        listaNotas.add(0, 5f);
        //listaNotas.set(0, "Victor");
        listaNotas.add(2.7f);
        
        for(int i = 0; i < listaNotas.size(); i++){
            System.out.println(listaNotas.get(i));
        }
        
        for(float aux : listaNotas){
            System.out.println(aux);
        }
        
        
        //Não garanto o mesmo tipo de dado
        ArrayList listaPresentes = new ArrayList();
        int soma = 0;
        listaPresentes.add(10);
        listaPresentes.add(12);
        listaPresentes.add(20);
        listaPresentes.add(2);
        
        for(int i = 0; i < listaPresentes.size(); i++){
            System.out.println(listaPresentes.get(i));
        }
        
        for(Object aux : listaPresentes){
            //int valor = (int) aux;
            soma = soma+((int) aux *2);
        }
        
        System.out.println("Soma: "+soma);
        
    }
    
}
