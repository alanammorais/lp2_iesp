package pacote1.subpacote;

public class Teste {

}
