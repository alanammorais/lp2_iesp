package pacote1;

public class ExemploClasse {
	
	public static void main(String args[]) {
		
		//boolean flag = true;
		
		float n1=10.2f, n2=5;
		float media;
		
		media = (n1+n2)/2;
		System.out.println("Valor da média calculada foi "+media+"\n\n");
		
		//System.out.println("O valor de x é:"+flag);
		System.out.println("Aula de Java - A melhor!!"); 
	}
	
}
