package model;

public class Aluno {
	
	//atributos 
	public String nome;
	public float nota1;
	public float nota2;
	public float nota3;
	
	//construtor
	public Aluno(String nome, float n1, float n2, float n3) {
		this.nome = nome;
		this.nota1 = n1;
		this.nota2 = n2;
		this.nota3 = n3;		
	}
	
	//metodos
	public float calcularMedia() {
		return (this.nota1+ this.nota2+ this.nota3)/3;
	}

}
