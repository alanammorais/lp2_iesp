package view;

import model.Aluno;

public class App_Universidade {

	public static void main(String[] args) {
		
		Aluno a1 = new Aluno("Leonardo", 10, 10, 10);
		System.out.println(a1.calcularMedia());
		
		a1.nota1 = 9.5f;
		System.out.println(a1.calcularMedia());
		
		
		Aluno a2 = new Aluno("Chico", 9, 9, 9);
		System.out.println(a2.calcularMedia());
		
		a1.nota2 = 5;		

	}

}
