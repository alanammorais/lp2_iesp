package view;

import model.Retangulo;

public class TesteRetangulo {

	public static void main(String[] args) {
		
		Retangulo r1 = new Retangulo(10, 2);
		System.out.println(r1.calcularArea());

	}

}
