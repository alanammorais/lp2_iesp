package pacote1;

public class ExemploClasse {
    
    public static void main(String args[]){
       System.out.println("Olá mundo");
    }
    
 
    
}
